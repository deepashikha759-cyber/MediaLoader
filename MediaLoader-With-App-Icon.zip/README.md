# MediaLoader Android starter

Native Kotlin Android app with:
- HTTPS direct-video URL checking
- Separate Preview Video and Download Video buttons
- Media3 ExoPlayer preview with play/pause, seek bar, and duration controls
- Android Sharesheet support for `ACTION_SEND` text URLs and shared video URIs
- Android DownloadManager for direct HTTPS video-file URLs

## Build requirements
- Android Studio
- JDK 17 (Android Studio's bundled JDK is fine)
- Android SDK Platform 35
- Internet access for Gradle to download dependencies

## Open and run
1. Extract this ZIP.
2. Android Studio → Open → select the extracted `MediaLoader` folder.
3. Wait for Gradle sync to finish.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press Run.

## Build an APK
Android Studio → Build → Build Bundle(s) / APK(s) → Build APK(s).
The debug APK is usually written to `app/build/outputs/apk/debug/app-debug.apk`.

## Test sharing
1. Install the app.
2. In a browser or another app, use Share on a direct video URL or ordinary URL.
3. Choose MediaLoader if it appears.
4. Shared text URLs populate the URL field. Tap Check Link.
5. A shared video file can be previewed directly using Preview Video.

## Scope and limitations
- This is a starter, not a universal downloader.
- The URL check is a format check, not a server-side verification that the file is accessible.
- DownloadManager only downloads direct URLs that the server allows the device to access.
- Social platform page links need an authorized API/integration and may not expose a downloadable file.
- Shared content access depends on the source app's Android intent and URI permissions.
- Media3 preview supports formats and protocols supported by the installed Media3 components and source server.


Diagnostic build note: This version adds a short Android Toast to each main button click so you can verify taps are received. This ZIP is source code, not a compiled APK. Build and test on a supported Android development environment before relying on it.
