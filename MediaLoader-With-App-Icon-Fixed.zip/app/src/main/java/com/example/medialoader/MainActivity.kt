package com.example.medialoader

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.net.URLDecoder
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var urlInput: EditText
    private lateinit var statusText: TextView
    private lateinit var checkButton: Button
    private lateinit var previewButton: Button
    private lateinit var downloadButton: Button
    private lateinit var playerView: PlayerView

    private var checkedUrl: String? = null
    private var sharedVideoUri: Uri? = null
    private var player: ExoPlayer? = null

    private val videoExtensions = listOf(".mp4", ".webm", ".mov", ".m4v", ".3gp", ".mkv")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun buildUi() {
        val backgroundColor = Color.rgb(13, 17, 30)
        val panelColor = Color.rgb(27, 34, 52)
        val purple = Color.rgb(124, 58, 237)
        val white = Color.WHITE
        val muted = Color.rgb(185, 192, 210)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(backgroundColor)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(30), dp(24), dp(24))
        }
        scroll.addView(root)

        val logo = TextView(this).apply {
            text = "⬇"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(white)
            background = rounded(purple, 18)
            layoutParams = LinearLayout.LayoutParams(dp(58), dp(58)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(14)
            }
        }
        root.addView(logo)

        root.addView(TextView(this).apply {
            text = "MediaLoader"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(white)
        })

        root.addView(TextView(this).apply {
            text = "Your links. Your downloads."
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(0, dp(6), 0, dp(28))
        })

        root.addView(label("Paste a direct video URL", white))
        urlInput = EditText(this).apply {
            hint = "https://example.com/video.mp4"
            hintTintListCompat(Color.rgb(145, 153, 174))
            setTextColor(white)
            textSize = 14f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_URI
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(panelColor, 12)
        }
        root.addView(urlInput, matchWrap().apply {
            topMargin = dp(8)
            bottomMargin = dp(14)
        })

        checkButton = Button(this).apply {
            text = "Check Link"
            setTextColor(white)
            background = rounded(purple, 12)
            isAllCaps = false
            setOnClickListener { Toast.makeText(this@MainActivity, "Check Link button tapped", Toast.LENGTH_SHORT).show(); checkLink() }
        }
        root.addView(checkButton, matchWrap().apply { bottomMargin = dp(10) })

        previewButton = Button(this).apply {
            text = "Preview Video"
            setTextColor(white)
            background = rounded(Color.rgb(65, 73, 95), 12)
            isAllCaps = false
            isEnabled = false
            setOnClickListener { Toast.makeText(this@MainActivity, "Preview Video button tapped", Toast.LENGTH_SHORT).show(); previewSelectedVideo() }
        }
        root.addView(previewButton, matchWrap().apply { bottomMargin = dp(18) })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(panelColor, 14)
        }
        root.addView(card, matchWrap())

        card.addView(label("Video preview", white))
        playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(220)
            ).apply { topMargin = dp(12); bottomMargin = dp(12) }
        }
        card.addView(playerView)

        statusText = TextView(this).apply {
            text = "Paste a direct video-file link or share a compatible video/link to MediaLoader."
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(12), 0, dp(16))
        }
        card.addView(statusText)

        downloadButton = Button(this).apply {
            text = "Download Video"
            isAllCaps = false
            setTextColor(white)
            background = rounded(Color.rgb(65, 73, 95), 12)
            isEnabled = false
            setOnClickListener { Toast.makeText(this@MainActivity, "Download Video button tapped", Toast.LENGTH_SHORT).show(); startDownload() }
        }
        card.addView(downloadButton, matchWrap())

        root.addView(TextView(this).apply {
            text = "MediaLoader previews direct video files and compatible shared video files. Downloads are limited to direct HTTPS video URLs and sources that permit downloading. A shared social-media page may not provide a downloadable file."
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(18), 0, 0)
        })
        setContentView(scroll)
    }

    private fun checkLink() {
        val raw = urlInput.text.toString().trim()
        checkedUrl = null
        sharedVideoUri = null
        previewButton.isEnabled = false
        downloadButton.isEnabled = false
        downloadButton.background = rounded(Color.rgb(65, 73, 95), 12)

        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        if (uri == null || uri.scheme != "https" || uri.host.isNullOrBlank()) {
            statusText.text = "Enter a valid HTTPS URL."
            return
        }

        val path = uri.lastPathSegment?.lowercase(Locale.ROOT).orEmpty()
        if (videoExtensions.none { path.endsWith(it) }) {
            statusText.text = "This looks like a webpage, not a direct video file. Try a direct video URL or share a video file with MediaLoader."
            return
        }

        checkedUrl = uri.toString()
        previewButton.isEnabled = true
        downloadButton.isEnabled = true
        previewButton.background = rounded(Color.rgb(65, 73, 95), 12)
        downloadButton.background = rounded(Color.rgb(124, 58, 237), 12)
        statusText.text = "Direct video URL detected. Preview it or download it if the server permits access."
    }

    private fun handleIncomingIntent(incoming: Intent?) {
        if (incoming?.action != Intent.ACTION_SEND) return

        val mime = incoming.type.orEmpty()
        val streamUri = if (android.os.Build.VERSION.SDK_INT >= 33) {
            incoming.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            incoming.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
        }

        if (streamUri != null && (mime.startsWith("video/") || mime == "application/octet-stream")) {
            sharedVideoUri = streamUri
            checkedUrl = null
            urlInput.setText("")
            previewButton.isEnabled = true
            downloadButton.isEnabled = false
            downloadButton.background = rounded(Color.rgb(65, 73, 95), 12)
            statusText.text = "Received a shared video file. Tap Preview Video to play it. This shared file is not a remote download link."
            return
        }

        val sharedText = incoming.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()?.trim()
        if (!sharedText.isNullOrBlank()) {
            val extractedUrl = Regex("https?://\\S+", RegexOption.IGNORE_CASE)
                .find(sharedText)?.value?.trimEnd('.', ',', ')', ']', '>')
            if (extractedUrl != null) {
                urlInput.setText(extractedUrl)
                statusText.text = "Link received from another app. Tap Check Link to inspect it."
                checkedUrl = null
                sharedVideoUri = null
                previewButton.isEnabled = false
                downloadButton.isEnabled = false
            } else {
                statusText.text = "Received shared text, but no URL was found."
            }
        } else {
            statusText.text = "The shared item did not include a supported URL or video file."
        }
    }

    private fun previewSelectedVideo() {
        val mediaUri = sharedVideoUri ?: checkedUrl?.let(Uri::parse)
        if (mediaUri == null) {
            statusText.text = "Check a direct video link or share a video file first."
            return
        }

        try {
            releasePlayer()
            playerView.visibility = View.VISIBLE
            player = ExoPlayer.Builder(this).build().also { exoPlayer ->
                playerView.player = exoPlayer
                exoPlayer.setMediaItem(MediaItem.fromUri(mediaUri))
                exoPlayer.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        statusText.text = "Preview failed. The source may block playback or use an unsupported format."
                    }
                })
                exoPlayer.prepare()
                exoPlayer.playWhenReady = true
            }
            statusText.text = "Preview ready. Use the player controls to pause, seek, and check duration."
        } catch (e: Exception) {
            statusText.text = "Couldn't start preview: ${e.localizedMessage ?: "unsupported media"}"
        }
    }

    private fun startDownload() {
        val url = checkedUrl ?: return
        try {
            val uri = Uri.parse(url)
            val rawName = uri.lastPathSegment?.let {
                runCatching { URLDecoder.decode(it, "UTF-8") }.getOrDefault(it)
            } ?: "video.mp4"
            val safeName = rawName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                .take(100).ifBlank { "video.mp4" }

            val request = DownloadManager.Request(uri)
                .setTitle(safeName)
                .setDescription("Downloading with MediaLoader")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)

            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(this, "Download started. Check your Downloads notification.", Toast.LENGTH_LONG).show()
            statusText.text = "Download queued: $safeName"
        } catch (e: Exception) {
            statusText.text = "Couldn't start download: ${e.localizedMessage ?: "unknown error"}"
        }
    }

    override fun onStart() {
        super.onStart()
        player?.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }

    private fun releasePlayer() {
        playerView.player = null
        player?.release()
        player = null
    }

    private fun label(text: String, color: Int) = TextView(this).apply {
        this.text = text
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(color)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun EditText.hintTintListCompat(color: Int) {
        setHintTextColor(color)
    }
}
